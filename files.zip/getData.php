<?php
	session_start();
	if(!isset($_SESSION['user'])){
		header("Location: login-form.php");
		exit();
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="css/bootstrap.min.css">
  	<script src="js/jquery.min.js"></script>
  	<script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/getData.css">

	<script type="text/javascript" src="js/getData.js"></script>

</head>
<body onbeforeprint="fff()" onafterprint="ffff()">
	


	<?php

		require "header.php";
		require "mydatabase.php";
		?>

			
			
			<input autofocus="autofocus" value="<?php if(isset($_GET['item'])){echo $_GET['item'];}?>" style="direction: ltr;width: 700px;margin: 0 auto;display: flex;justify-content: center;background-color: #eee" type="text" id="myInput" onkeyup="myFunction()" placeholder="Filter according to the item name: ">
			<?php if(isset($_GET['item'])){echo "<script>setTimeout(function(){myFunction();}, 1000)</script>";}?>
			


		<?php
		
		
			$sql = "SELECT item_name, item_quantity,Item_price FROM items order by `item_name`";
		
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
		  // output data of each row
			$i=1;
			?>
			
				<div style="overflow: auto;height: auto;margin-top: 10px;display: flex;justify-content: center;">
				<table style="direction: ltr;font-size: 16pt;width: 700px" id="myTable" class="table table-hover table-responsive" >
						<tr>
		    			<th class="HH">Item Name</th>
		    			<th style="width: 140px" class="HH">Quantity</th>
		    			<th style="width: 140px" class="HH">Price</th>
		    		</tr>
		    		
			<?php
			$s=1;
		  while($row = $result->fetch_assoc()) {
		  	
		    ?>
		    		<tr class="TR">
		    			<td style="position: relative;" class="DD" id="linkName_<?php echo $s; ?>"><a style="position: absolute;left: 10px;color: #333;text-decoration: none;" href="edit_goods.php?name=<?php echo  $row["item_name"]?>">&#9998;</a><?php echo  $row["item_name"]?></td>
		    			<td style="width: 140px" class="DD"><?php echo  $row["item_quantity"]?></td>
		    			<td style="width: 140px" class="DD"><?php echo  $row["Item_price"]?></td>
		    		</tr>
		    	
		    <?php

		    $s++;
		  }

		  	?>
		   		
		  		</table>
		  		</div>
		  	<?php
		}
		$conn->close();
		
	?>











	
</body>
</html>