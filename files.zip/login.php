<?php
echo "Welcom here</br>";
 if($_SERVER['REQUEST_METHOD'] == 'POST'){
	echo "server method passed</br>";
	if(isset($_POST['submitLogin'])){
		echo "submitLogin passed</br>";
		include 'mydatabase.php';
		echo "require database passed</br>";
		$username=$conn->real_escape_string($_POST['username']);
		$password=$conn->real_escape_string($_POST['password']);
		echo "passe getting variables</br>";
		$sql4="SELECT username,password,type FROM users WHERE (username=?) ";
		$stmt=$conn->prepare($sql4);
		if($stmt){
			$stmt->bind_param("s",$username);
			$stmt->execute();
			$stmt->bind_result($varUserName,$varPassword,$varType);
			while($stmt->fetch()){
				// print_r(md5($varPassword));
				// md5($password)
				echo "inside while before checking user and pass</br>";
				if($username==$varUserName&&$password==$varPassword){
					session_start();
					echo "login is done </br>";
					$_SESSION['user']=$username;
					$_SESSION['type']=$varType;
					header("Location: index.php?Loggedin");
					exit();
				}
			}

			if($username!=$varUserName||md5($password)!=$varPassword){
				header("Location: login-form.php?LoginFailed");
				exit();	
			}
			
		}else{
			header("Location: login-form.php?LoginError");
			exit();	
		}

	}else{
		header("Location: login-form.php?Error4=LoginFirst!");
	}
}else{
	echo "wrong server requiest";
//	header("Location: login-form.php?Error3=CannotAccessThisPageDirectly!");
}

?>
