<?php
  session_start();
  if(!isset($_SESSION['user'])){
    header("Location: login-form.php");
    exit();
  }elseif (isset($_GET['notused'])) {
    ?>
      <script type="text/javascript">
        if(window.parent.location=='http://localhost/new_goods.php?notused=insertedSuccessfully'){
          location.replace("getData.php");
        }
      </script>
    <?php
    
  }
?>
<?php
include_once "header.php";
?>
<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="refresh" content="">
  	<link rel="stylesheet" href="css/bootstrap.min.css">
  	<script src="js/jquery.min.js"></script>
  	<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/new_goods.css">
<body>

<?php
	if(isset($_GET['used']) && $_GET['used']=="ThisNameIsAlreadyExsisted!"){
		?>
			<p class="sorry">Sorry, the item is already exists!</p>
		<?php
	}elseif(isset($_GET['notused']) && $_GET['notused']=="insertedSuccessfully"){
    ?>
      <p class="success">Added successfully</p>
    <?php
  }
?>
<div class="container">
<h3 style="text-align: center;color: white">New Item</h3>
<form style="direction: ltr;margin-top: 0px;" id="regForm" method="POST" action="add_new_goods.php">
  
  <div class="tab">
    <p><input id="itemName" placeholder="New Item Name: "  name="itemname" autofocus="autofocus" required></p>
    
  </div>
  <div class="tab">
    <p><input type="number" placeholder="Item Quantity: " id="noK"   name="noK" ></p>
  </div>

  <div class="tab">
    <p> <input step="any" type="number" placeholder="Item Price: "  name="price" ></p>
  </div>


      <button type="submit" id="nextBtn">Add Item</button>
</form>

<input id="itemNameId" type="hidden" name="" value="<?php if (isset($_GET['itemName'])) {echo $_GET['itemName']; } ?>">
</div>

</body>
</html>