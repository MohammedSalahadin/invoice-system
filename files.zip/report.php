<?php
	session_start();
	if(!isset($_SESSION['user'])){
		header("Location: login-form.php");
		exit();
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta charset="utf-8">
	<meta http-equiv="refresh" content="">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="css/bootstrap.min.css">
  	<script src="js/jquery.min.js"></script>
  	<script src="js/bootstrap.min.js"></script>
  	<style type="text/css">
		@media print{
  			body{
  				-webkit-print-color-adjust: exact !important;
  			}
  		}

  		*{
  			border: none !important;
  		}

  		body{
  			direction: ltr;
  			background-color: #222222
  		}
  		table {
		  width: 700px;
		  border-collapse: collapse;
		  border: none !important;
		  table-layout: auto;
		  overflow-x: scroll;
		  margin: 0 auto;
		  font-size: 14pt
		}

		table, td, th {
		  direction: ltr;
		  text-align: center;
		  border: none !important;
		  border-spacing: unset;


		}

		td,th{
			border: 0px solid #ddd;
		}

		th {
			text-align: center;
			border: 0px solid #ddd;
			background-color: #2d86ad
		}

		td{
			background-color: #70bbfc
		}


		thead{
			display: table-header-group;
			border: 0px solid #ddd;
			

		}

		.title{
			font-weight: bolder;
			
			font-size: 16pt;
			color: whitesmoke

		}

		.title1{
			font-weight: bolder;
			
			font-size: 25pt;
			color: whitesmoke

		}

		tr:hover{
			color: whitesmoke !important
		}
  	</style>
</head>
<body>
	<?php
		require "header.php";
		require "mydatabase.php";
		echo "<h1 class='title1' style='direction:ltr;text-align:center;margin-bottom:20px;color:whitesmoke'>"."Report of day:  ".date("Y/m/d")."</h1>";
	?>

	<table style="direction: ltr;width: 60%;border:0px;font-size: 18pt" class="table table-responsive table-hover ">
		<thead>
			<tr>
				<td class="title" style="background-color: #111 !important;" colspan="2">Sold Section</td>
			</tr>
			<tr>
				<th colspan="1" >Item</th>
				<th >Quantity Sold</th>
			</tr>
		</thead>
			
		

		<?php
			$sql="SELECT * FROM sell_report;";

			$result=$conn->query($sql);
			if($result->num_rows>0){
				$i=1;
				while($row=$result->fetch_assoc()){
					?>
						<tr>
							<td colspan="1"><?php echo $row['Name'] ?></td>
							<td><?php echo $row['No_of_k'] ?></td>
						</tr>
					<?php
				}
			}

			

		?>
		<tr><td class="title" style="background-color: #111 !important;" colspan="2" align="center">Invoice Section</td></tr>
		<thead>
			<tr>
				<th >Invoice No.</th>
				<th >Invoice Price</th>
			</tr>
		</thead>
			
		


		<?php
			$sql2="SELECT * FROM `invoice_database`.`sell_report_invoices`;";

			$result2=$conn->query($sql2);
			if($result2->num_rows>0){
				$i=1;
				?>
					<style type="text/css">.direct{color: gray}</style>
					<style type="text/css">.not{font-weight: }</style>
				<?php
				$totPrice=0;
				$pay=0;
				while($row2=$result2->fetch_assoc()){
					
						?>
							<tr class="not">
								<td><?php echo $row2['invoiceID'] ?></td>
								<td><?php echo str_replace('.00', '', number_format($row2['price'],2,'.',',')) ;$totPrice=$totPrice+$row2['price']; ?></td>
							</tr>
						<?php
					
					
				}
				

			}

			

		?>


		
		
	

	

	<?php
		$sql3="SELECT * FROM total_invoices_price_for_today;";
		$result3=$conn->query($sql3);
		if($result3->num_rows>0){
			$row3=$result3->fetch_assoc();
		}

		
	?>
	<tr><td class="title" style="background-color: #111 !important;" colspan="2">Conclusion</td></tr>
		<tr>
			<td colspan="1">Today sales price</td>
			<td><?php echo str_replace('.00', '', number_format($row3['totInvoicePrice'],2,'.',','));?></td>
		</tr>
		
	</table>
<?php
	$conn->close();
?>
</body>
</html>