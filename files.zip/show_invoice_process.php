<?php
  session_start();
  if(!isset($_SESSION['user'])){
    header("Location: login-form.php");
    exit();
  }
?>
<?php
$invoiceID = intval($_GET['q']);
    
    require "mydatabase.php";
    $sql7="SELECT i.`invoiceID`,g.`item_name`,cgq.`quantity`,g.`Item_price`,cgq.`quantity`*g.`Item_price` as 'Total_K_P',date_format(i.`date`,'%Y/%m/%d - %H:%i:%s') as 'date' FROM `invoice` i join invoice_items cgq on cgq.`invoice_invoiceID`=i.`invoiceID` join items g on g.`ID`=cgq.`items_ID`  WHERE i.`invoiceID`=$invoiceID order by g.`item_name`;";
      $result8 = $conn->query($sql7);
      $ID=0;
      if ($result8->num_rows > 0) {
      $row8 = $result8->fetch_assoc();
      $ID=$row8['invoiceID'];
      
      
      
      }else{
        exit();
      }

      
  

?>

<!DOCTYPE html>
<html>
  <head>
    <title></title>
    <meta http-equiv="refresh" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="css/show_invoice_process.css">
 
</head>
<body>
  
      
      

  <div class="container" style="background-color: lightyellow">
  <div class="containsheader">

    <div class="info">
      <p style="font-family: 'Segoe UI';font-size: 30pt;color: #333;margin-top: 25px;padding-right: 0px;text-align: center;" class="header">Market </p>
      <hr class="horiz">
      <p style="font-size: 13pt;font-weight: bold;padding-top: 3px;text-align: left;" class="header">Info Info Info Info </p>
      
<br>
      <p style="font-size: 13pt;font-weight: bold;text-align: left;" class="header">Address Address Address Address</p>
      <p style="font-size: 15pt;font-weight: bold;text-align: left;" class="header">0770000000 - 0750000000</p>
    </div>
    

    

    <div class="date">
      <p class="header" style="margin: 32.50px auto;text-align: center;font-size: 15pt;color: #333"><?php echo $row8['date']; ?></p>
      <hr class="horiz">
      <p class="invoiceNum"><?php echo $row8['invoiceID']; ?></p>
    </div>

    
  </div>
     

    
    <div class="containsLines">
    </div>
    <div class="containstable">
    <table class="table1">
      <tr>
        
        <td style="padding: 5px;text-align: left;" colspan="3">Sir: <span style="border-bottom: 1px dotted black;"></span></td>
        <td style="padding: 5px;text-align: left;" colspan="4">Address: <span style="border-bottom: 1px dotted black;"></span></td>
      </tr>
      <tr style="background-color: #ccc">
        <th class="hh1">No.</th>
        <th class="hh2">Item Name </th>
        <th class="hh">Quantity </th>
        <th class="hh">Price</th>
        <th class="hh">Total </th>
      </tr>


      <?php
      $f=new NumberFormatter("ar", NumberFormatter::SPELLOUT);//stop xampp, go to php.ini, remove ; from before extension=intl
       
          $result7 = $conn->query($sql7);
          if ($result7->num_rows > 0) {
            $total=0;
            $u=1;
            $allTotal=0;
            $pay=0;
            $totNoK=0;
            $totNoP=0;
              while($row7 = $result7->fetch_assoc()) {
                  
      ?>
                <tr>
                <td style="text-align: center;" class="hh1"><?php echo $u;?></td>
                <td style="text-align: left;" class="hh2"><?php echo $row7['item_name']; ?></td>
                <td class="hh"><?php if(!empty($row7['quantity'])){echo $row7['quantity'];$totNoK=$totNoK+$row7['quantity'];}  ?></td>
                <td class="hh"><?php echo str_replace('.00', '', number_format($row7['Item_price'],2,'.',',')) ;  ?></td>
                
                <td class="hh"><?php $total=$row7['Total_K_P'];echo str_replace('.00', '', number_format($total,2,'.',',')) ;$allTotal=$allTotal+$total ?></td>
              </tr>
      <?php
              $u++;
            }
          }
        $conn->close();
      ?>


      

      <tr style="display: hidden">
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>



      <tr>
        <td colspan=""></td>
        <td></td>
        <td class="hh"><?php echo $totNoK;?></td>
        
        <td></td>
        <td class="hh"><?php echo str_replace('.00', '', number_format($allTotal,2,'.',',')); ?></td>
      </tr>

      <tr style="display: hidden">
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>

    </table>
  </div>
    
    <div class="footer">
      

            
      
    </div>
  </div>
  
  
  
</body>

</html>
              
          
   

        
        
        
