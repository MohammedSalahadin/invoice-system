<?php
	session_start();
	if(!isset($_SESSION['user'])){
		header("Location: login-form.php");
		exit();
	}
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	require "mydatabase.php";
	$itemname=$_POST['itemname'];
	$noK=$_POST['noK'];
	$price=$_POST['price'];
	

	
	$name=$conn->real_escape_string($itemname);
	$qt=$conn->real_escape_string($noK);
	$p=$conn->real_escape_string($price);

	if(empty($name)){
		header("Location: new_goods.php?emptyName");
		exit();
	}
	$sql2="SELECT item_name FROM items WHERE item_name=?"; //we can use an easer way by fetch them all then comparing them with $username.
			$stmt2=$conn->prepare($sql2);
			$stmt2->bind_param("s",$name);
			$stmt2->execute();
			$stmt2->bind_result($var);

					while($stmt2->fetch()){
						$var;
						if($var==$name){
							header("Location: new_goods.php?used=ThisNameIsAlreadyExsisted!");
							exit();
						}
					}
			$stmt2->close();


	$sql="INSERT INTO items (item_name,Item_price,item_quantity) VALUES (?,?,?)";
							
	$stmt=$conn->prepare($sql);
		if(!$stmt){
			header("Location: new_goods.php?fail=DataIsNotInserted!");
			exit();
		}else{
			$stmt->bind_param("sdi",$name,$p,$qt);

			if($stmt->execute()){
				$stmt->close();
				header("Location: new_goods.php?notused=insertedSuccessfully&itemName=$name");
			}
								

		}



	
}

?>