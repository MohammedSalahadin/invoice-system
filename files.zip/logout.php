
<?php
		session_start();
		if(isset($_SESSION['user'])){
			session_unset();
			session_destroy();
			header("Location: login-form.php?loggedOut");
			exit();	
		}else{
			header("Location: login-form.php?Error4=LoginFirst!");
			exit();	
		}


	


?>