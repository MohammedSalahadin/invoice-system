function reset(){
	document.getElementById("myInput").value="";
}

function show(value){
	var arr=value.split(",");
	var result=(+arr[1])+(+1);
	document.getElementById(value).style.display="flex";
	document.getElementById('add'+value).style.display="none";
	document.getElementById('add'+'F,'+result).style.display="block";
}
	
function uset(value){
	var y="itemList_";
	var numKelement="numKelement_"+value;
	var name=y.concat(value);
	setTimeout(function() {//we need to have this amount of time to check first if elem!='' in the unsetProgress() function. Otherwise, will be empty first and the condition will never be = true
		document.getElementsByName(name)[0].value="";
		document.getElementById(numKelement).value="";
		
	}, 10);


}

	
function count_item() {
	var i=1;
	var numberOfItem=0;
	while(i<=20){
		if(document.getElementById('itemListNum_'+i).value!=""){
			numberOfItem++;
		}
		i++;
	}
	document.getElementById('labelForProgress').innerHTML=numberOfItem;
	
}


var customersIDArr=[];






	

