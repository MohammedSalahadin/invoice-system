
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta http-equiv="refresh" content="">
  <style type="text/css">
    li{
      text-align: left;
      list-style-position: inside;
    }

    .navbar{
      position: sticky;
      top: 0px
    }

    
    .dropdown:hover>.dropdown-menu{
      display: block;
    }
  </style>

  <script type="text/javascript">
    function classs(value) {
      value.setAttribute('class','dropdown active');
    }

    function unset(value) {
      value.setAttribute('class','dropdown');
    }
  </script>
</head>
<body>






<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">O</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav ">
        <li class="active "><a style="font-size: 13pt;font-weight: bold;" href="index.php">Main</a></li>
        <li onmouseout="unset(this)" onmousemove="classs(this)" class="dropdown "><a style="font-size: 13pt;font-weight: bold;" class="dropdown-toggle" data-toggle="dropdown dropdown-menu" href="#">Item<span class="caret"></span></a>
          <ul class="dropdown-menu">
            
            <li><a style="font-size: 13pt;font-weight: bold;" href="new_goods.php">Add New Item</a></li>
            <li><a style="font-size: 13pt;font-weight: bold;" href="edit_goods.php">Edit Item</a></li>
            <li><a style="font-size: 13pt;font-weight: bold;" href="getData.php">Item Table</a></li>
          </ul>
        </li>
          
          <li onmouseout="unset(this)" onmousemove="classs(this)" class="dropdown "><a style="font-size: 13pt;font-weight: bold;" class="dropdown-toggle" data-toggle="dropdown dropdown-menu" href="#">Invoices<span class="caret"></span></a>
            <ul class="dropdown-menu">     
              <li><a style="font-size: 13pt;font-weight: bold;" href="delete_invoice.php">Delete Invoice</a></li> 
              <li><a style="font-size: 13pt;font-weight: bold;" href="show_invoice.php">Show Invoice</a></li> 
            </ul>
          </li>
          
          
          <li onmouseout="unset(this)" onmousemove="classs(this)" class="dropdown "><a style="font-size: 13pt;font-weight: bold;" class="dropdown-toggle" data-toggle="dropdown dropdown-menu" href="#">Report<span class="caret"></span></a>
            
            <ul class="dropdown-menu">
              <li><a style="font-size: 13pt;font-weight: bold;" href="report.php">Daily Report</a></li>      
              <li><a style="font-size: 13pt;font-weight: bold;" href="report_date.php">Date Based Report</a></li> 
            </ul>
          </li>
          
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <?php
            if($_SESSION['type']=='admin'){
              ?>
                <li><a style="font-size: 13pt;font-weight: bold;" href="">Add Emp.</a></li>
              <?php
            }
          ?>
          <li onclick="return confirm('Are you sure!')"><a style="font-size: 13pt;font-weight: bold;" href="logout.php">Logout</a></li>
          
         
        </ul>
    </div>
  </div>
</nav>







</body>
</html>