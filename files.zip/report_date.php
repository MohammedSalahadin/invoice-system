<?php
  session_start();
  if(!isset($_SESSION['user'])){
    header("Location: login-form.php");
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="refresh" content="">
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style type="text/css">
    body{
      background-color: #222222
    }

      table {
      width: 700px;
      border-collapse: collapse;
      table-layout: auto;
      overflow-x: scroll;
      margin: 0 auto;
      font-size: 14pt
    }

    table, td, th {
      padding: 5px;
      direction: ltr;
      text-align: center;
      border: none !important;
    }

    td,th{
      border: 1px solid #ddd;
    }

    th {
      text-align: center;
      border: 1px solid #ddd;
      background-color: #2d86ad
    }

    td{
      background-color: #70bbfc
    }


    thead{
      display: table-header-group;
      border: 0px solid #ddd;
    }

    .mainPage{
      padding: 5px;
      font-weight: bold;
      font-size: 14pt;
      background-color: inherit;
      color: black;
      border: 0px;
      position: absolute;
      transition: 1s;
      border-radius: 25%;
    }

    

    form{
      margin: 0 auto;
      display: flex;
      justify-content: center;
      flex-flow: column;
      width: 150px;
      direction: ltr;

    }

    .submit{
          width:130px;
          background-color:#111;
          border-radius:5px;
          border:2px solid #111;
          padding: 15px;
          color:white;
          font-size: 15pt;
          display: flex;
          justify-content: center;
          margin: 10px auto;
          cursor: pointer;
          outline: none;
          transition: 0.5s;
          top:50%;
        }
    .hoverBack:hover{
          background-color: tomato;
        }
    </style>
  
<script>
function move() {
  // body...
  var id=document.getElementById('mainPage');
  id.style.transform = 'rotateX(360deg)'

}

function out() {
  // body...
  var id=document.getElementById('mainPage');
  id.style.transform = '';

}

function hide() {
  document.getElementById('mainPageLink').style.display = 'none';
  document.getElementById('form1').style.display = 'none';

}

function show() {
  document.getElementById('mainPageLink').style.display = '';
  document.getElementById('form1').style.display = '';

}
</script>
</head>
<body onbeforeprint="hide()" onafterprint="show()">
  <a href="index.php" id="mainPageLink" ><button onmouseleave ="out()" id="mainPage" class="submit hoverBack" style="position: fixed;left: 100px;z-index: 2" >&#60;&#60; Back</button></a>
<form id="form1" style="margin-top: 40px">
<input autofocus style="margin-top: 5px;width: 150px" type="date" name="from" required id="from">
<input style="margin-top: 5px;width: 150px" type="date" name="to" required id="to">
<input style="margin-top: 5px;width: 150px" type="submit" name="submitDates">
</form>

<?php
  if(isset($_GET['from']) && isset($_GET['to'])){
      $from1=date_create($_GET['from']);
      $to1=date_create($_GET['to']);

      $days=date_diff($from1,$to1);
      if($days->format("%R%a days")>=0){
      $from = $_GET['from'];
      $to = $_GET['to'];
    


    echo "<h1 style='direction:ltr;text-align:center;margin-bottom:20px;color:whitesmoke'>"."Sells Report from ".$from." to ".$to."</h1>";
  ?>

  <table style="direction: ltr;width: 50%;border:0px;font-size: 18pt" class="table table-responsive table-hover ">
    <thead>
      <tr>
        <th colspan="2">Item</th>
        <th>Quantity</th>
      </tr>
    </thead>
      
    

    <?php
      require "mydatabase.php";
      $sql="call SELL_REPORT_SPECIFIC_DATE('".$from."', '".$to."');";

      $result=$conn->query($sql);
      if($result->num_rows>0){
        $i=1;
        while($row=$result->fetch_assoc()){
          ?>
            <tr>
              <td colspan="2"><?php echo $row['Name'] ?></td>
              <td><?php echo $row['No_of_k'] ?></td>
            </tr>
          <?php
        }
      }

      

    ?>


    
    

  <?php
    require "mydatabase.php";
    $sql3="call TOTAL_INVOICES_PRICES_FOR_SPECIFIC_DATE('".$from."', '".$to."');";
    $result3=$conn->query($sql3);
    if($result3->num_rows>0){
      $row3=$result3->fetch_assoc();
    }

    
  ?>

  <thead>
    <tr>
      <th colspan="3">Conclusion</th>
    </tr>
  </thead>

    <tr>
      <td colspan="2">Total Income</td>
      <td><?php echo str_replace('.00', '', number_format($row3['totInvoicePrice'],2,'.',',')) ;?></td>
    </tr>
  </table>
<?php
  $conn->close();
}else{
  ?>
    <script type="text/javascript">
      alert("Input the old date then the date after!");
    </script>
  <?php
}
}
?>



</body>
</html>