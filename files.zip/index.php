<?php
	session_start();
	if(!isset($_SESSION['user'])){
		header("Location: login-form.php");
		exit();
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Main Page</title>
	<meta charset="utf-8">
	<meta http-equiv="refresh" content="">
	  <meta name="viewport" content="width=device-width, initial-scale=4">
  	<link rel="stylesheet" href="css/bootstrap.min.css" />
  	<script src="js/jquery.min.js"></script>
  	<script src="ls/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/index.css" />
	

<script type="text/javascript" src="js/index.js"></script>



</head>
<body>
<?php
	include_once "header.php";
?>
<h3 align="center" style="color: white">INVOICE</h3>



<?php
	if(isset($_GET['message']) && $_GET['message']=='NoCusName'){
		?>
			  <div class="alert alert-danger warry">
			    <strong>Alert, </strong> No Customer Name!
			  </div>
		<?php
	}elseif (isset($_GET['message']) && $_GET['message']=='NoItemName') {
		?>
			  <div class="alert alert-danger warry">
			    <strong>Alert, </strong>No Item Name!
			  </div>
		<?php
	}elseif (isset($_GET['message']) && $_GET['message']=='numKPelement') {
		?>
			  <div  class="alert alert-danger warry">
			    <strong>Alert, </strong> Specify the quantity.
			  </div>
		<?php
	}elseif (isset($_GET['message']) && $_GET['message']=='notEnoughPnotEnoughK') {
		?>
			  <div  class="alert alert-danger warry">
			    <strong>Alert, </strong> There is only <?php echo $_GET['enoughK']?> Qt of <?php echo $_GET['notEnoughKP']?>
			  </div>
		<?php
	}elseif (isset($_GET['message']) && $_GET['message']=='notEnoughK') {
		?>
			  <div  class="alert alert-danger warry">
			    <strong>Alert, </strong> There is only <?php echo $_GET['enough']?> item of <?php echo $_GET['notEnoughK']?>
			  </div>
		<?php
	}elseif (isset($_GET['message']) && $_GET['message']=='emptyInvoice') {
		?>
			  <div  class="alert alert-danger warry">
			    <strong>Alert, </strong> Empty Invoice!
			  </div>
		<?php
	}elseif (isset($_GET['message']) && $_GET['message']=='TwoSameItems') {
		?>
			  <div  class="alert alert-danger warry">
			    <strong>Alert, </strong> Two same Items!
			  </div>
		<?php
	}
?>





<center>
	<button id="addF,1" class="add" onclick="show('F,1')">+</button>
	<?php

		$num=1;
		while ($num <= 20) {
			?>
			<button id="addF,<?php echo $num+1;?>" class="addd" onclick="show('F,<?php echo $num+1;?>');">+<?php echo $num;?></button>
			<?php
			$num++;
		}
	?>
</center>



<div class="MAIN">
	<div class="containsMain">
		


<?php 
	
	function f(){
		require "mydatabase.php";
		$sql = "SELECT `item_name`,`Item_price`,`item_quantity` FROM items";
		$resArr = array();
		$result = $conn->query($sql);
	
		  while($row = $result->fetch_assoc()) {
		  	$resArr[]=$row;
		  }
	  return $resArr;
	}
?>
<?php $valueName=""; if(isset($_GET['customerName'])){ $valueName=$_GET['customerName']; } ?>

<form style="background-color: ;border-top: 0px" action="index_process.php" id="mainform" method="POST" name="mainform">
	
	<input value="<?php echo $valueName; ?>" required  style="display: flex !important;justify-content: center !important;margin: 10px auto" class="inputt" type="text" name="customerName" placeholder="Customer Name: ">
	
	

	<?php
	$i=1;
	$itemListReturn=null;
	if(isset($_GET['itemList'])){
		$itemListReturn=unserialize(urldecode($_GET['itemList']));
	}
	
	while($i<=20){
		?>
			<span id="F,<?php echo $i;?>" class="myForm">
			<span onmousemove="count_item()" title="Romove Text" style="display: inline-block;margin: auto 0; cursor: pointer;font-size: 15pt;" 
			onclick="count_item();uset(<?php echo $i;?>);">&times;</span>	
				
		    	
		    	<?php 
		    		$valueItemAcc="";
		    		if($itemListReturn!=null){
		    			$valueItem=$itemListReturn[$i];
		    		}
		    		
		    		if(!empty($valueItem)){
		    			$valueItemAcc=$valueItem; 
		    		} 
		    	?>
				<input placeholder="Item Name:" onmouseleave="count_item()" value="<?php echo $valueItemAcc; ?>" class="inputt" list="itemList_a_<?php echo $i;?>" name="itemList_<?php echo $i;?>" id="itemListNum_<?php echo $i;?>">
				
				<datalist id="itemList_a_<?php echo $i;?>">
					<?php
						$sideBarPosts = f(); 

						if($itemListReturn!=null){
		    				$value=$itemListReturn[$i];
		    			}

						if(!empty($value)){
							?>
								<script>
									show('F,<?php echo "$i";?>');
								</script>
							<?php
						}
							foreach($sideBarPosts as $post) { 
								?>
							    	<option id="option_<?php echo $i;?>" label="Max Qt. = <?php echo $post["item_quantity"];?>      |      Price = <?php echo $post["Item_price"];?>" 
								<?php 
								    	
								?> 
								    value='<?php echo $post["item_name"];?>'
								<?php 
								    
	
							   	?> 
							    	>

							    <?php
							}
						
					?>
					
				</datalist>
				<?php
				$value1=null;
				if(isset($_GET['numKelement'])){
					$numKelement=unserialize(urldecode($_GET['numKelement']));
					$value1=$numKelement[$i];
				}

				// $value3=null;
				// if(isset($_GET['KP'])){
				// 	$KP=unserialize(urldecode($_GET['KP']));
				// 	$value3=$KP[$i];
				// }
				
				?>

				<input  min="0" <?php if($value1!=null){ ?>value="<?php echo $value1; ?>"<?php } ?> class="inputt2" type="number" name="numKelement_<?php echo $i;?>" id="numKelement_<?php echo $i;?>" placeholder="Qt.">
				<!-- <input min="0" step="any" <?php if($value3!=null){ ?>value="<?php echo $value3; ?>"<?php } ?> class="inputt3" type="number" id="KP_<?php echo $i;?>"  placeholder="Price: "> --><!-- name="KP_<?php echo $i;?>" -->
			</span>
		<?php
		$i++;
	}

	?>
	
	<input onmousemove="count_item()" name="submitInvoice" class="submit" type="submit" value="Check">
	<center><font style="border-top:1px solid black;padding: 5px;border-radius: 0px;" color="white"><span> All Items: </span><span class="" id="labelForProgress">0</span></font></center>

</form>
</div>
<button class="addd"><?php echo $num;?></button>
</div>



</body>
</html>