<?php
    session_start();
    if(!isset($_SESSION['user'])){
        header("Location: login-form.php");
        exit();
    }
?>

<?php
include_once "header.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="">
<link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/edit_goods.css">



</head>
<body>

    <div class="container">
  <h3 style="text-align: center;color: white">Edit Item Info.</h3>
  <form  method="POST" action="edit_goods_process.php" style="direction: ltr;margin-top: 0px;" id="regForm">
      <div class="">
        <input type="text" class="form-control link" id="" placeholder="Item Name" name="Name1" value="<?php 
        if(isset($_GET['value'])){
            echo $_GET["value"];
        }elseif(isset($_GET['sendCopy'])){
            echo $_GET["sendCopy"];
        }elseif(isset($_GET['name'])){echo $_GET['name'];}?>" required>
      </div>
      <div class="">
        <select class="selectOption1" name="selectOption1">
            <option value="name" <?php if(isset($_GET['selected'])&&$_GET['selected']=='name'){echo "selected";}?>>Edit Item Name</option>
            <option <?php if(isset($_GET['sendCopy'])){echo 'selected';} ?> value="NoK" <?php if(isset($_GET['selected'])&&$_GET['selected']=='NoK'){echo "selected";}?>>Edit Quantity</option>
            <option value="BP" <?php if(isset($_GET['selected'])&&$_GET['selected']=='BP'){echo "selected";}?>>Edit Price</option>
        </select>
        </div>
    
      <div class="">
        <input  type="text" class="form-control" id="" placeholder="Change to: " name="NewValue1" required>
      </div>
    
    
    
      <div class="">
        <input type="submit" class=" update" name="update" value="Update">
        

      </div>
      <a style="text-decoration: none;" <?php if(isset($_GET['name'])){$item=$_GET['name'];echo "href='getData.php?item=$item'";}?>><button style="height: 50px" type="button" class=" update">Check</button></a>
  </form>
  </div>
  <?php
    if(isset($_GET['message']) && $_GET['message']=="NumericOnly!"){
        ?>
            <p class="Wrong">Enter Numeric Value Only</p>
            <script type="text/javascript">alert("Fail!");</script>
        <?php
    }elseif(isset($_GET['message']) && $_GET['message']=="RecordUpdatedSuccessfully!"){
        ?>
            <p class="Success">Updated Successfully</p>
        <?php
    }elseif(isset($_GET['message']) && $_GET['message']=="ThereIsAnotherMaterialWithTheSameName"){
        ?>
            <p class="Wrong">There is another material with the same name</p>
            <script type="text/javascript">alert("Fali!");</script>
        <?php
    }elseif(isset($_GET['message']) && $_GET['message']=="ThisGoodsThatYouWantToEditIsNotExsisted!"){
        ?>
            <p class="Wrong">This item that you want to edit is not exsisted</p>
            <script type="text/javascript">alert("فشل");</script>
        <?php
    }
        
    


  ?>
  



</body>
</html> 