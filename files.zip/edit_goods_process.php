<?php
	session_start();
	if(!isset($_SESSION['user'])){
		header("Location: login-form.php");
		exit();
	}
?>
<?php
if (isset($_POST['update'])) {
	require "mydatabase.php";
	
	$Name1=$_POST["Name1"];
	$selectOption1=$_POST["selectOption1"];
	$NewValue1=$_POST["NewValue1"];
	
	$Name=$conn->real_escape_string($Name1);
	$selectOption=$conn->real_escape_string($selectOption1);
	$NewValue=$conn->real_escape_string($NewValue1);

	$sql = "SELECT `ID` FROM `items` where `item_name`='".$Name."'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	  $row = $result->fetch_assoc();
	  $id=$row["ID"];
	  	
	  	if($selectOption=="name"){
			$sql2="UPDATE `items` SET `item_name` = '".$NewValue."' WHERE `ID` = '".$id."'";
		}elseif ($selectOption=='NoK') {
			if(is_numeric($NewValue)){
				$sql2="UPDATE `items` SET `item_quantity` = '".$NewValue."' WHERE `ID` = '".$id."'";
			}else{
				header("Location: edit_goods.php?message=NumericOnly!&selected=$selectOption&value=$Name");
	  			exit();
			}
		}elseif ($selectOption=='BP') {
			if(is_numeric($NewValue)){
				$sql2="UPDATE `items` SET `Item_price` = '".$NewValue."' WHERE `ID` = '".$id."'";
			}else{
				header("Location: edit_goods.php?message=NumericOnly!&selected=$selectOption&value=$Name");
	  			exit();
			}
		}

			if ($conn->query($sql2) === TRUE) {
				$conn->close();
				header("Location: edit_goods.php?message=RecordUpdatedSuccessfully!&name=$Name");
			}elseif ($conn->error=="Duplicate entry '".$NewValue."' for key 'Name_UNIQUE'") {
				header("Location: edit_goods.php?message=ThereIsAnotherMaterialWithTheSameName");
	  			exit();
			} else {
			  echo "Error updating record: " . $conn->error;
			}
		
	} else {
	  header("Location: edit_goods.php?message=ThisGoodsThatYouWantToEditIsNotExsisted!");
	  exit();
	}
		
		
	}


$conn->close();
?>