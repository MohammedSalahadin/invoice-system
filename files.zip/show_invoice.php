<?php
  session_start();
  if(!isset($_SESSION['user'])){
    header("Location: login-form.php");
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="refresh" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  position: fixed;
  top: 5px;
  left: 5px;
}

.submit{
      width:130px;
      background-color:#111;
      border-radius:5px;
      border:2px solid #111;
      padding: 15px;
      color:white;
      font-size: 15pt;
      display: flex;
      justify-content: center;
      margin: 10px auto;
      cursor: pointer;
      outline: none;
      transition: 0.5s;
      top:50%;
    }
.hoverBack:hover{
      background-color: tomato;
    }

body{
  background-color: #222222
}

.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
</style>
<script>
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","show_invoice_process.php?q="+str,true);
  xmlhttp.send();
}

function hide(){
  document.getElementById('note').style.display="none";
  document.getElementById('button5').style.display="none";
  document.getElementById('form').style.display="none";
}

function showw(){
  document.getElementById('note').style.display="";
  document.getElementById('button5').style.display="";
  document.getElementById('form').style.display="";
}
</script>
</head>
<body onbeforeprint="hide()" onafterprint="showw()">
  <a href="index.php" title="Home Page"><button class="submit hoverBack" style="position: fixed;left: 100px;z-index: 2" >&#60;&#60; Back</button></a>

  <p id='note' style='text-align:center;'>
    <?php
      require "mydatabase.php";
      $sql="SELECT invoiceID FROM invoice order by invoiceID asc;";
      $sql2="SELECT i.`invoiceID` FROM invoice i WHERE (DATE(i.`date`)=curdate()) order by i.`invoiceID` limit 1;";
      $result = $conn->query($sql);
      $result2 = $conn->query($sql2);
      if ($result2->num_rows > 0) {
        $row2 = $result2->fetch_assoc() ;
        echo "<font color='white'>Today invoices start from No. : ".$row2['invoiceID']."</font>";
      }
    ?>
  </p>



<form dir="ltr" id="form" style="margin: 50px auto 10px auto; background-color: ">
<input list="invoiceID" id="browser" autofocus style="margin: 0px auto;display: flex;justify-content: center;width: 300px;text-align: center;" name="users" onkeyup="showUser(this.value)" onchange="showUser(this.value)">

<datalist id="invoiceID">
  <option value="" label="Choose the Invoice No.">
  <?php
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        ?>
        <option value="<?php echo $row['invoiceID']?>"><?php echo $row['invoiceID']?>
        <?php
      }

    }
  ?>
</datalist>


</form>
<br>
<div id="txtHint" style="text-align: center;"><b style="color: white">The invoice will be shown here</b></div>

</body>
</html>






