<?php
	session_start();
	if(!isset($_SESSION['user'])){
		header("Location: login-form.php");
		exit();
	}
?>

<?php
if($_SERVER['REQUEST_METHOD']!='POST'){
	header("Location:index.php");
	exit();
}

if(isset($_POST['submitInvoice'])){
	require "mydatabase.php";
	$conn->autocommit(false);

$payment=$_POST['payment'];
$customerName=$_POST['customerName'];
$totalInvoice=$_POST['totalInvoice'];
$errorArray=array();

$itemList=array("");
$numKelement=array("");
$KP=array("");
$loop=1;
while ($loop <= 20) {
	array_push($itemList, $_POST['itemList_'.$loop]);
	array_push($numKelement, $_POST['numKelement_'.$loop]);
	array_push($KP, $_POST['KP_'.$loop]);
	$loop++;
}

require "mydatabase.php";



$a=1;
while($a<=20){
	if(!empty($itemList[$a])){
			$sql = "UPDATE items SET item_quantity=item_quantity-'$numKelement[$a]' WHERE `item_name`='$itemList[$a]';";

			if ($conn->query($sql) === TRUE) {
			} else {
			  echo "Error updating record1: " . $conn->error;
			  array_push($errorArray, "Error updating record1");
			}

			

		
	}
	$a++;
}

$sql="SELECT CUSTOMER_ID('".$_SESSION['user']."');";
$result = $conn->query($sql);
		
		$invoiceID=0;
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			$CUSTOMER_ID=$row["CUSTOMER_ID('".$_SESSION['user']."')"];
			if(!empty($CUSTOMER_ID)){
				$sql = "INSERT INTO `invoice` (`user_id`) VALUES ('$CUSTOMER_ID');";
			}
			

			if ($conn->query($sql) === TRUE) {
				$lastInvoiceId=$conn->insert_id;
				$invoiceID=$lastInvoiceId;
			} else {
			  echo "Error2: " . $sql . "<br>" . $conn->error;
			  array_push($errorArray, "Error2");
			}
		}

		$z=1;
		if($invoiceID!=0 && !empty($itemList) ){
			while ($z <= 20) {
				$sql="SELECT `ID` FROM items WHERE `item_name`= '".$itemList[$z]."'";
				$result = $conn->query($sql);
				$row = $result->fetch_assoc();

				$IID=$invoiceID;
				$idItem=$row['ID'];
				$K=0;
				$KPrice=0;
				if(!empty($numKelement[$z])){
					$K=$numKelement[$z];
				}

				

				if(!empty($KP[$z])){
					$KPrice=$KP[$z];
				}

				
				
				

				if(!empty($idItem) && ($K!=0 || $K!=null || $K!="")){
					//$sqlPrices="SELECT K_Price,Piece_Price FROM goods WHERE `ID`=".$idItem."";
					//$resultPrices = $conn->query($sqlPrices);
					//$rowPrices = $resultPrices->fetch_assoc();
				$sql3="INSERT INTO `invoice_items` (`invoice_invoiceID`, `items_ID`, `quantity`) VALUES (".$IID.", ".$idItem.", ".$K.");";
				if ($conn->query($sql3) === TRUE) {
				} else {
				  echo "Error3: " . $sql3 . "<br>" . $conn->error;
				  array_push($errorArray, "Error3");
				}
				}
				$z++;
			}
		}

		
		

		$sql5="UPDATE `invoice` SET `price` = $totalInvoice WHERE (`invoiceID` = $invoiceID);";
		
		
			if ($conn->query($sql5) === TRUE) {


			} else {
			  echo "Error updating record5: " . $conn->error;
			  array_push($errorArray, "Error updating record5");
			}

	if($conn->connect_errno){
		array_push($errorArray, "connect_errno");
	}

	if($conn->connect_error){
		array_push($errorArray, "connect_error");
	}

	if(!empty($errorArray)){
		$conn->rollback();
	}else{
		if(!$conn->commit()){
			echo "Transaction Process Failed";
			exit();
		}else{
			?>
				  	
				<form style="display: none;" action="index_process_2.php" method="POST">
					<input type="text" name="customerName" value="<?php echo $customerName;?>">
					<input type="number" name="invoiceID" value="<?php echo $invoiceID;?>">
					<input id="submitInvoiceId1" type="submit" name="submitInvoiceId">
				</form>

				<script type="text/javascript">
					function click1(){
						var x=document.getElementById("submitInvoiceId1");
						x.click();
					}
							
					click1();
						
				</script>
					
			<?php
		}
	}

	

			



	

$conn->close();




}




?>