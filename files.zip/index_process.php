<?php
	session_start();
	if(!isset($_SESSION['user'])){
		header("Location: login-form.php");
		exit();
	}
?>
<?php
if($_SERVER['REQUEST_METHOD']!='POST'){
	header("Location:index.php");
	exit();
}

if(isset($_POST['submitInvoice'])){

$customerName=$_POST['customerName'];

$itemList=array("");
$numKelement=array("");
$loop=1;
while ($loop <= 20) {
	array_push($itemList, $_POST['itemList_'.$loop]);
	array_push($numKelement, $_POST['numKelement_'.$loop]);
	$loop++;
}


	function search($value,$hestack){		
		$z=0;
		for ($i=0; $i < count($hestack); $i++) {

			if($hestack[$i]==$value && !empty($hestack[$i])){
				$z++;
				if($z>=2){
					header("Location:index.php?message=TwoSameItems");
					exit();
				}
			}
		}
	}

$e=0;
while ($e <= 20) {
	search($itemList[$e],$itemList);
	$e++;
}



$i=1;
while($i<=20){
	if(empty($itemList[$i]) && !empty($numKelement[$i])){
	header("Location:index.php?message=NoItemName&customerName=$customerName&itemList=".urlencode(serialize($itemList))."&numKelement=".urlencode(serialize($numKelement)));
	exit();
	}
$i++;
}

$s=1;
$q=0;
while($s<=20){
	if(empty($itemList[$s]) && empty($numKelement[$s])){
		$q++;//just in case all of them are empty, the q will be equal to 15
		if($q==20){
			header("Location:index.php?message=emptyInvoice");
			exit();
		}
	}
$s++;
}

$x=1;
while($x<=20){
	if(!empty($itemList[$x]) && empty($numKelement[$x])){
	header("Location:index.php?i=$x&message=numKPelement&customerName=$customerName&itemList=".urlencode(serialize($itemList))."&numKelement=".urlencode(serialize($numKelement)));
	exit();
	}
$x++;
}

$w=1;
require "mydatabase.php";

while($w<=20){
if(!empty($itemList[$w]) && !empty($numKelement[$w]) ){
	
	$sql = "SELECT ID,item_quantity FROM items WHERE `item_name`='$itemList[$w]'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
		if(!empty($numKelement[$w])){
			if ($numKelement[$w]>$row['item_quantity'] ) {
				$numOfK=$row['item_quantity'];
				header("Location:index.php?i=$w&message=notEnoughPnotEnoughK&notEnoughKP=$itemList[$w]&enoughP=$numOfP&enoughK=$numOfK&customerName=$customerName&itemList=".urlencode(serialize($itemList))."&numKelement=".urlencode(serialize($numKelement)));
				exit();
			}
		}   
		  
	}
	

}
$w++;
}
}




?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="refresh" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index_process.css">
	<script type="text/javascript">
		function goBack(){
			window.history.back();
		}
	</script>
	<style type="text/css">
		*{
			direction: ltr;
		}
	</style>
</head>
<body style="direction: ltr;">
	<button class="submit hoverBack" style="position: fixed;left: 100px;z-index: 2" onclick="goBack()">&#60;&#60; Back</button>


	<div class="container">
		

		<div class="date">
			<p class="header">Date: </p>
		</div>

		<div class="info">
			<p class="header">Invoice NO:</p>
			<p class="header">Customer Name: <?php echo $customerName;?></p>
		</div>
		
		<hr class="long"><hr class="short">
		<table class="table1">
			<tr>
				<th class="hh1">S</th>
				<th class="hh2">Item</th>
				<th class="hh">Quantity</th>
				<th class="hh">Price</th>
				
				<th class="hh">Total</th>
			</tr>


			<?php
			$s=1;
			$u=1;
			$total=0;
			$allTotal=0;
			while ($s <= 20) {
				$totalKP=0;
				

				

				
				if(!empty($itemList[$s])){
					$sql = "SELECT * FROM items WHERE `item_name`='".$itemList[$s]."'";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					  // output data of each row
					  while($row = $result->fetch_assoc()) {
					    $KPrice=$row['Item_price'];
			 			

			 			
			 			?>
			 			<tr>
							<td style="text-align: center;" class="hh1"><?php echo $u++;?></td>
							<td style="text-align: left;" class="hh2"><?php echo $itemList[$s];?></td>
							<td class="hh"><?php if(!empty($numKelement[$s])){echo $numKelement[$s];$totalKP=$numKelement[$s]*$KPrice;} ?></td>
							<td class="hh"><?php if(!empty($numKelement[$s])){echo str_replace('.00', '', number_format($KPrice,2,'.',','));} ?></td>
							
							<td class="hh"><?php $total=$totalKP;echo str_replace('.00', '', number_format($total,2,'.',','));$allTotal=$allTotal+$total ?></td>
						</tr>
						<?php
					  }
					}
				}
				
			$s++;
			}

			$conn->close();
			?>


			

			<tr style="display: hidden">
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>

			<tr>
				<td style="display: hidden;border: 0px;"></td>
				<td style="display: hidden;border: 0px;"></td>
				<td style="display: hidden;border: 0px;"></td>
				<td class="hh">All Total</td>
				<td class="hh"><?php echo str_replace('.00', '', number_format($allTotal,2,'.',','));?></td>
			</tr>

			

			<tr>
				<td style="display: hidden;border: 0px;"></td>
				<td style="display: hidden;border: 0px;"></td>
				<td style="display: hidden;border: 0px;"></td>
				<td class="hh"><button id="payBTNTot" style="display: none;position: absolute;width: 100px;text-align: center" onclick="document.getElementById('payNow').value='<?php echo $allTotal;?>'">Paid</button>Payment</td>
				
				<form id="nameForm"  style="direction: rtl;" action="invoicefinal.php" method="POST">
					<td class="hh"><input oninput="document.getElementById('payBTNTot').style.display='block';" autofocus required max="<?php echo $allTotal;?>" placeholder="...123" style="border:0px" class="hh" type="number" step="any" name="payment" id="payNow" ></td>
					<input type="hidden" name="customerName" value="<?php echo $customerName;?>">
					<input value="<?php echo $allTotal; ?>" type="hidden" name="totalInvoice">
						<?php
							$i=1;
							while($i<=20){
								?>
									<input value="<?php echo $itemList[$i]; ?>" type="hidden" name="itemList_<?php echo $i;?>" >
									<input value="<?php echo $numKelement[$i]; ?>" type="hidden" name="numKelement_<?php echo $i;?>" >
									<input value="<?php echo $KP[$i]; ?>" type="hidden" name="KP_<?php echo $i;?>">
								<?php
								$i++;
							}
						?>
						

				</form>
			</tr>

			
		</table>
		
	</div>
	

	<input style="position: fixed;right: 100px;" form="nameForm" class="submit confirm" style="" type="submit" name="submitInvoice" value="Confirm &#62;&#62;">
	
	
</body>
</html>