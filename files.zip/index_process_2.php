<?php
	session_start();
	if(!isset($_SESSION['user'])){
		header("Location: login-form.php");
		exit();
	}
?>
<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['submitInvoiceId'])){
		
		require "mydatabase.php";
		$invoiceID=$_POST['invoiceID'];
		$totalInvoice=0;
		$customerName=$_POST['customerName'];
		$sql7="SELECT i.`invoiceID`,i.`price`,g.`item_name`,cgq.`quantity`,g.`Item_price`,cgq.`quantity`*g.`Item_price` as 'Total_K_P',date_format(i.`date`,'%Y/%m/%d - %H:%i:%s') as 'date' FROM invoice i join invoice_items cgq on cgq.`invoice_invoiceID`=i.`invoiceID` join items g on g.`ID`=cgq.`items_ID`  WHERE i.`invoiceID`=$invoiceID order by g.`item_name`;";
			$result8 = $conn->query($sql7);
			$ID=0;
			if ($result8->num_rows > 0) {
				$row8 = $result8->fetch_assoc();
				$ID=$row8['invoiceID'];
				$totalInvoice=$row8['price'];
			}

			
	}
}else{
	header("Location:index.php?message=cannotaccessDirectly!");
	exit();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="refresh" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index_process_2.css">
	<script type="text/javascript">
		function hideee() {
				var x=document.getElementById('main');
				x.style.display='none';
				var y=document.getElementById('print');
				y.style.display='none';
				document.getElementById('container1').style.position="relative";
				document.getElementById('container1').style.left="0px";
		}

		function show(){
			var x=document.getElementById('main');
				x.style.display='block';
			var y=document.getElementById('print');
				y.style.display='block';
			document.getElementById('container1').style.position="absolute";
			document.getElementById('container1').style.left="150px";
				//document.getElementById("main").click();
		}
	</script>
</head>
<body onbeforeprint="hideee()" onafterprint="show()" >
	<a href="index.php"><button style="" id="main" class="submit submit3"><span style="font-weight: bold;transform: rotate();"></span> Done &nbsp;&#xbb;</button></a>
	<button class="submit2 submit3" id="print"  onclick="window.print();">Print <span style="font-weight: bold;">&nbsp; &#xbb;</span></button>

	
			
			

	<div id="container1" class="container" style="background-color: lightyellow;">
	<div class="containsheader">

		<div class="info">
			<p style="font-family: 'Segoe UI';font-size: 30pt;color: #333;margin-top: 25px;padding-right: 0px;text-align: center;" class="header">MARKET</p>
			<hr class="horiz">
			<p style="font-size: 13pt;font-weight: bold;padding-top: 3px" class="header">Description Description Description Description</p>
<br>
			<p style="font-size: 13pt;font-weight: bold;" class="header">Address Address Address Address</p>
			<p style="font-size: 15pt;font-weight: bold;" class="header">077000000000 - 075000000000 </p>
		</div>
		

		

		<div class="date">
			<p class="header" style="margin: 32.50px auto;text-align: center;font-size: 15pt;color: #333"><?php echo $row8['date']; ?></p>
			<hr class="horiz">
			<p class="invoiceNum"><?php echo $row8['invoiceID']; ?></p>
		</div>

		
	</div>
		

		
		<div class="containsLines">
		</div>
		<div class="containstable">
		<table class="table1">
			<tr>
				<?php
					$inID=$row8['invoiceID'];
				?>
				<td style="padding: 5px" colspan="3">Sir:  <span style="border-bottom: 1px dotted black;"><?php echo $customerName; ?></span></td>
				
				<td style="padding: 5px" colspan="4">Address:  <span style="border-bottom: 1px dotted black;"><!-- <?php echo $row8['address']; ?> --></span></td>
			</tr>
			<tr style="background-color: #ccc">
				<th class="hh1">S</th>
				<th class="hh2">Item Name</th>
				<th class="hh">Qauntity</th>
				<th class="hh">Price</th>
				
				<th class="hh">Total</th>
			</tr>


			<?php
			 
					$result7 = $conn->query($sql7);
					if ($result7->num_rows > 0) {
						$total=0;
						$u=1;
						$allTotal=0;
						$pay=0;
						$totNoK=0;
						
						$pay=$totalInvoice;
					  	while($row7 = $result7->fetch_assoc()) {
					  	
					  			
			?>
						  	<tr>
								<td style="text-align: center;" class="hh1"><?php echo $u;?></td>
								<td style="text-align: left;" class="hh2"><?php echo $row7['item_name']; ?></td>
								<td class="hh"><?php if(!empty($row7['quantity'])){echo $row7['quantity'];$totNoK=$totNoK+$row7['quantity'];}  ?></td>
								<td class="hh"><?php if(!empty($row7['Item_price']) && !empty($row7['quantity'])){echo str_replace('.00', '', number_format($row7['Item_price'],2,'.',','));}  ?></td>
								<td class="hh"><?php $total=$row7['Total_K_P'];echo str_replace('.00', '', number_format($total,2,'.',','));$allTotal=$allTotal+$total ?></td>
							</tr>
			<?php
							$u++;
						}
					}
				$conn->close();
			?>


			

			




			<tr style="display: hidden;height: 5px">
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>

			<tr style="">
				<td></td>
				<td></td>
				<td></td>
				<td class="hh">Invoice Price</td>
				<td class="hh"><?php echo str_replace('.00', '', number_format($totalInvoice,2,'.',',')); ?></td>
			</tr>

			<tr style="">
				<td></td>
				<td></td>
				<td></td>
				<td class="hh">Payment</td>
				<td class="hh"><?php echo str_replace('.00', '',  number_format($pay,2,'.',',')); ?></td>
			</tr>

			

			
		</table>
	</div>
		<hr class="footer">
		
	</div>
	
	
	
</body>
</html>
			  			
			    
				
				
				

				
				
				
