
<?php 
$servername='127.0.0.1';
$username='root';
$password='root';
echo "finish declaring";
$myDatabase='invoice_database';
$conn=new mysqli($servername,$username,$password,$myDatabase);
	if(mysqli_connect_error()){
  		echo "<p style='position:fixed;top:100px;left:0px;'>";
		die("Connection Failed: ".mysqli_connect_error()."<br>"."<br>"."<br>"."<br>"."<br>"."You may forgot to start mysql from xampp server!");
  	echo "</p>";
}else{
	
}
